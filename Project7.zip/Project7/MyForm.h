#pragma once

namespace Project7 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	a[M][N];
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
		}

	protected:
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^ textBoxN;
	private: System::Windows::Forms::TextBox^ textBoxM;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Label^ labelSum;
	private: System::Windows::Forms::Button^ buttonDone;
	private: System::Windows::Forms::Label^ label1;

	private: System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		   void InitializeComponent(void)
		   {
			   this->textBoxN = (gcnew System::Windows::Forms::TextBox());
			   this->textBoxM = (gcnew System::Windows::Forms::TextBox());
			   this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			   this->labelSum = (gcnew System::Windows::Forms::Label());
			   this->buttonDone = (gcnew System::Windows::Forms::Button());
			   this->label1 = (gcnew System::Windows::Forms::Label());
			   (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			   this->SuspendLayout();
			   // 
			   // textBoxN
			   // 
			   this->textBoxN->Location = System::Drawing::Point(17, 16);
			   this->textBoxN->Margin = System::Windows::Forms::Padding(4);
			   this->textBoxN->Name = L"textBoxN";
			   this->textBoxN->Size = System::Drawing::Size(132, 22);
			   this->textBoxN->TabIndex = 0;
			   this->textBoxN->TextChanged += gcnew System::EventHandler(this, &MyForm::textBoxN_TextChanged);
			   // 
			   // textBoxM
			   // 
			   this->textBoxM->Location = System::Drawing::Point(160, 16);
			   this->textBoxM->Margin = System::Windows::Forms::Padding(4);
			   this->textBoxM->Name = L"textBoxM";
			   this->textBoxM->Size = System::Drawing::Size(132, 22);
			   this->textBoxM->TabIndex = 1;
			   this->textBoxM->TextChanged += gcnew System::EventHandler(this, &MyForm::textBoxM_TextChanged);
			   // 
			   // dataGridView1
			   // 
			   this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			   this->dataGridView1->Location = System::Drawing::Point(17, 49);
			   this->dataGridView1->Margin = System::Windows::Forms::Padding(4);
			   this->dataGridView1->Name = L"dataGridView1";
			   this->dataGridView1->RowHeadersWidth = 51;
			   this->dataGridView1->Size = System::Drawing::Size(533, 246);
			   this->dataGridView1->TabIndex = 2;
			   // 
			   // labelSum
			   // 
			   this->labelSum->AutoSize = true;
			   this->labelSum->Location = System::Drawing::Point(17, 308);
			   this->labelSum->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			   this->labelSum->Name = L"labelSum";
			   this->labelSum->Size = System::Drawing::Size(44, 16);
			   this->labelSum->TabIndex = 3;
			   this->labelSum->Text = L"label1";
			   // 
			   // buttonDone
			   // 
			   this->buttonDone->Location = System::Drawing::Point(20, 328);
			   this->buttonDone->Margin = System::Windows::Forms::Padding(4);
			   this->buttonDone->Name = L"buttonDone";
			   this->buttonDone->Size = System::Drawing::Size(100, 28);
			   this->buttonDone->TabIndex = 4;
			   this->buttonDone->Text = L"Done";
			   this->buttonDone->UseVisualStyleBackColor = true;
			   this->buttonDone->Click += gcnew System::EventHandler(this, &MyForm::buttonDone_Click);
			   // 
			   // label1
			   // 
			   this->label1->AutoSize = true;
			   this->label1->Location = System::Drawing::Point(412, 13);
			   this->label1->Name = L"label1";
			   this->label1->Size = System::Drawing::Size(44, 16);
			   this->label1->TabIndex = 5;
			   this->label1->Text = L"label1";
			   // 
			   // MyForm
			   // 
			   this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			   this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			   this->ClientSize = System::Drawing::Size(567, 369);
			   this->Controls->Add(this->label1);
			   this->Controls->Add(this->buttonDone);
			   this->Controls->Add(this->labelSum);
			   this->Controls->Add(this->dataGridView1);
			   this->Controls->Add(this->textBoxM);
			   this->Controls->Add(this->textBoxN);
			   this->Margin = System::Windows::Forms::Padding(4);
			   this->Name = L"MyForm";
			   this->Text = L"MyForm";
			   this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			   (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			   this->ResumeLayout(false);
			   this->PerformLayout();

		   }
#pragma endregion

	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void textBoxN_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void textBoxM_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
		   int CalculateSumOfPositiveElements(int N, int M) {
			   int count = 0;
			   for (int i = 0; i < N; i++) {
				   for (int j = 0; j < M; j++) {
					   if (a[i][j] % 5 == 0 & a[i][j] % 3 == 0)
						   count++;
				   }
			   }
			   return count;
		   }

		   System::Void FillArray(int N, int M) {
			   Random^ rand = gcnew Random();
			   for (int i = 0; i < N; i++) {
				   for (int j = 0; j < M; j++) {
					   a[i][j] = rand->Next(50, 150);
				   }
			   }
		   }

		   System::Void DisplayArray(int N, int M) {
			   dataGridView1->Rows->Clear();
			   dataGridView1->Columns->Clear();
			   dataGridView1->ColumnCount = M;
			   dataGridView1->RowCount = N;
			   for (int i = 0; i < N; i++) {
				   for (int j = 0; j < M; j++) {
					   dataGridView1->Rows[i]->Cells[j]->Value = a[i][j];
				   }
			   }
		   }

	private: System::Void buttonDone_Click(System::Object^ sender, System::EventArgs^ e) {
		int N, M;
		if (Int32::TryParse(textBoxN->Text, N) && Int32::TryParse(textBoxM->Text, M)) {
			FillArray(N, M);
			DisplayArray(N, M);
			int sum = CalculateSumOfPositiveElements(N, M);
			labelSum->Text = "Counts : " + sum.ToString();
		}
	}

	};
}